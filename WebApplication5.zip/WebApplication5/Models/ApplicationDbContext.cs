﻿using Microsoft.EntityFrameworkCore;
using System.Numerics;

namespace WebApplication5.Models
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

        public DbSet<Class> Person { get; set; }
    }
}

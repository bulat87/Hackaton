﻿namespace WebApplication5.Models
{
    public class TableClass
    {
    }
}

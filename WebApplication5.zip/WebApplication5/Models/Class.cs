﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore.Metadata.Internal;

namespace WebApplication5.Models
{
    public class Class
    {
        private readonly ApplicationDbContext _context;
        public string nickname { get; set; }

        public string Mail { get; set; }

        public int coin { get; set; }
        public Class(ApplicationDbContext context)
        {
            _context = context;
        }
        /*
        public IActionResult Index()
        {
            var players = _context.Person.ToList();
            
        }
        */
    }
}

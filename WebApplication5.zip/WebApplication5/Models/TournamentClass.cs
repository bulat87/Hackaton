﻿namespace WebApplication5.Models
{
    public class TournamentClass
    {
        public int Id { get; set; }
    }
}

﻿using Microsoft.AspNetCore.Mvc;

namespace WebApplication5.Controllers
{
    public class TableController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        
    }
}

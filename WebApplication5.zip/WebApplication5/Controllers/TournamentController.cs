﻿using Microsoft.AspNetCore.Mvc;

namespace WebApplication5.Controllers
{
    public class TournamentController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}

﻿using Microsoft.AspNetCore.Mvc;

namespace WebApplication5.Controllers
{
    public class ClassController : Controller   //Регистрация
    {
       
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult Check()
        {
            return View("Index");
        }
    }
}
